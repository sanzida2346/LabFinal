package com.example.mukti;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText firstNumber;
    private EditText secondNumber;
    private Button sumButton;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNumber = findViewById(R.id.firstNumberEd);
        secondNumber = findViewById(R.id.secondNumberEd);
        sumButton = findViewById(R.id.btn);
        result = findViewById(R.id.result);

        sumButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String number1 = firstNumber.getText().toString();
                String number2 = secondNumber.getText().toString();

                int a = Integer.parseInt(number1);
                int b = Integer.parseInt(number2);

                int sumResult = a + b;
                result.setText("Result : " + sumResult);
            }
        });
    }
}












